These files contain the necessary information to manufacture
a printed circuit board.

Board Name: DS2480B-DONGLE
Release Date: 8/27/2021

The files included are:
1-  ReadMe.txt             This file
2-  DS2480B-DONGLE.GTL     Top side routing layer
3-  DS2480B-DONGLE.GBL     Bottom side routing layer
4-  DS2480B-DONGLE.GTO     Top side silk screen mask
5-  DS2480B-DONGLE.GBO     Bottom side silk screen mask
6-  DS2480B-DONGLE.GTS     Top side solder mask
7-  DS2480B-DONGLE.GBS     Bottom side solder mask
8-  DS2480B-DONGLE.GKO     Board outline
9-  DS2480B-DONGLE.TXT     Text of drill file

NOTE:

1) The Gerber files include RS427X embedded apertures. No separate
   aperture file is provided.

FAB INSTRUCTIONS:
- Vendor and process shall be UL 94V-0 approved.
- Boards must be marked with vendor identification and UL 94V-0
- Material: FR4
- Thickness 0.062"
- Vias: Top-Bottom only.
- Solder mask: LPI   Color: green
- Silkscreen on both sides. Color: white
- Fab tolerance .XX = +/- .005
- Copper Weight:  1 Oz Copper on all layers
- Holes specified as larger than 0.021" diameter must remain open.
  Smaller diameter holes may be plugged or open.
