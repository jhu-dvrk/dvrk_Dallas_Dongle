These files contain the necessary information to assemble a PCB.

Board Name: DS2480B-DONGLE
Release Date: 8/27/2021

The files included are:
1-  ReadME.txt               This file
2-  DS2480B-DONGLE.GTP       Top side paste mask
3-  DS2480B-DONGLE.GBP       Bottom side paste mask
4-  DS2480B-DONGLE PnP.csv   Pick & Place file in CSV format
